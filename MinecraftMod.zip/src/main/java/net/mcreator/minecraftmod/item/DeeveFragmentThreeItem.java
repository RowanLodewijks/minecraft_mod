
package net.mcreator.minecraftmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class DeeveFragmentThreeItem extends Item {
	public DeeveFragmentThreeItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
