
package net.mcreator.minecraftmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.minecraftmod.init.MinecraftmodModFluids;

public class ArdaniumWaterItem extends BucketItem {
	public ArdaniumWaterItem() {
		super(MinecraftmodModFluids.ARDANIUM_WATER, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON));
	}
}
