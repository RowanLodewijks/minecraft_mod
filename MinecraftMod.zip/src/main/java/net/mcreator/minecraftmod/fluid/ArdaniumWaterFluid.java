
package net.mcreator.minecraftmod.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.minecraftmod.init.MinecraftmodModItems;
import net.mcreator.minecraftmod.init.MinecraftmodModFluids;
import net.mcreator.minecraftmod.init.MinecraftmodModFluidTypes;
import net.mcreator.minecraftmod.init.MinecraftmodModBlocks;

public abstract class ArdaniumWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> MinecraftmodModFluidTypes.ARDANIUM_WATER_TYPE.get(), () -> MinecraftmodModFluids.ARDANIUM_WATER.get(),
			() -> MinecraftmodModFluids.FLOWING_ARDANIUM_WATER.get()).explosionResistance(100f).tickRate(3).bucket(() -> MinecraftmodModItems.ARDANIUM_WATER_BUCKET.get()).block(() -> (LiquidBlock) MinecraftmodModBlocks.ARDANIUM_WATER.get());

	private ArdaniumWaterFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.EXPLOSION;
	}

	public static class Source extends ArdaniumWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends ArdaniumWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
