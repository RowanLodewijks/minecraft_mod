
package net.mcreator.minecraftmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.GhastModel;

import net.mcreator.minecraftmod.entity.ArdaniumAnimalEntity;

public class ArdaniumAnimalRenderer extends MobRenderer<ArdaniumAnimalEntity, GhastModel<ArdaniumAnimalEntity>> {
	public ArdaniumAnimalRenderer(EntityRendererProvider.Context context) {
		super(context, new GhastModel(context.bakeLayer(ModelLayers.GHAST)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(ArdaniumAnimalEntity entity) {
		return new ResourceLocation("minecraftmod:textures/entities/ghast.png");
	}
}
