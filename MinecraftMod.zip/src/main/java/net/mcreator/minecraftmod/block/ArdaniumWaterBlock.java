
package net.mcreator.minecraftmod.block;

import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.minecraftmod.init.MinecraftmodModFluids;

public class ArdaniumWaterBlock extends LiquidBlock {
	public ArdaniumWaterBlock() {
		super(() -> MinecraftmodModFluids.ARDANIUM_WATER.get(), BlockBehaviour.Properties.of(Material.WATER).strength(100f).noCollission().noLootTable());
	}
}
