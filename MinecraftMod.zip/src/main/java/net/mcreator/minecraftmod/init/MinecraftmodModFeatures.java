
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minecraftmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.minecraftmod.world.features.ores.ArdaniumOreFeature;
import net.mcreator.minecraftmod.world.features.OverworldBuildingFeature;
import net.mcreator.minecraftmod.world.features.ArdaniumBuildingFeature;
import net.mcreator.minecraftmod.MinecraftmodMod;

@Mod.EventBusSubscriber
public class MinecraftmodModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, MinecraftmodMod.MODID);
	public static final RegistryObject<Feature<?>> ARDANIUM_ORE = REGISTRY.register("ardanium_ore", ArdaniumOreFeature::new);
	public static final RegistryObject<Feature<?>> ARDANIUM_BUILDING = REGISTRY.register("ardanium_building", ArdaniumBuildingFeature::new);
	public static final RegistryObject<Feature<?>> OVERWORLD_BUILDING = REGISTRY.register("overworld_building", OverworldBuildingFeature::new);
}
