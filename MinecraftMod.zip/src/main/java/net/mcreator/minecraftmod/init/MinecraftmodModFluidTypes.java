
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minecraftmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.minecraftmod.fluid.types.ArdaniumWaterFluidType;
import net.mcreator.minecraftmod.MinecraftmodMod;

public class MinecraftmodModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, MinecraftmodMod.MODID);
	public static final RegistryObject<FluidType> ARDANIUM_WATER_TYPE = REGISTRY.register("ardanium_water", () -> new ArdaniumWaterFluidType());
}
