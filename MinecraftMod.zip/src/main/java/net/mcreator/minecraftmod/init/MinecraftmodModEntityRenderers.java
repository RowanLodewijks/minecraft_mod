
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minecraftmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.minecraftmod.client.renderer.DeeveRenderer;
import net.mcreator.minecraftmod.client.renderer.ArdaniumAnimalRenderer;
import net.mcreator.minecraftmod.client.renderer.ArdaniumAnimal3Renderer;
import net.mcreator.minecraftmod.client.renderer.ArdaniumAnimal2Renderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MinecraftmodModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MinecraftmodModEntities.DEEVE.get(), DeeveRenderer::new);
		event.registerEntityRenderer(MinecraftmodModEntities.ARDANIUM_ANIMAL.get(), ArdaniumAnimalRenderer::new);
		event.registerEntityRenderer(MinecraftmodModEntities.ARDANIUM_ANIMAL_2.get(), ArdaniumAnimal2Renderer::new);
		event.registerEntityRenderer(MinecraftmodModEntities.ARDANIUM_ANIMAL_3.get(), ArdaniumAnimal3Renderer::new);
	}
}
