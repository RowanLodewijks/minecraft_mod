
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minecraftmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.minecraftmod.item.DeeveFragmentTwoItem;
import net.mcreator.minecraftmod.item.DeeveFragmentThreeItem;
import net.mcreator.minecraftmod.item.DeeveFragmentOneItem;
import net.mcreator.minecraftmod.item.ArdaniumWaterItem;
import net.mcreator.minecraftmod.item.ArdaniumSwordItem;
import net.mcreator.minecraftmod.item.ArdaniumShovelItem;
import net.mcreator.minecraftmod.item.ArdaniumPickaxeItem;
import net.mcreator.minecraftmod.item.ArdaniumIngotItem;
import net.mcreator.minecraftmod.item.ArdaniumHoeItem;
import net.mcreator.minecraftmod.item.ArdaniumDimensionItem;
import net.mcreator.minecraftmod.item.ArdaniumAxeItem;
import net.mcreator.minecraftmod.item.ArdaniumArmorItem;
import net.mcreator.minecraftmod.MinecraftmodMod;

public class MinecraftmodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MinecraftmodMod.MODID);
	public static final RegistryObject<Item> ARDANIUM_BLOCK = block(MinecraftmodModBlocks.ARDANIUM_BLOCK);
	public static final RegistryObject<Item> ARDANIUM_INGOT = REGISTRY.register("ardanium_ingot", () -> new ArdaniumIngotItem());
	public static final RegistryObject<Item> DEEVE_SPAWN_EGG = REGISTRY.register("deeve_spawn_egg", () -> new ForgeSpawnEggItem(MinecraftmodModEntities.DEEVE, -3407668, -65281, new Item.Properties()));
	public static final RegistryObject<Item> ARDANIUM_ORE = block(MinecraftmodModBlocks.ARDANIUM_ORE);
	public static final RegistryObject<Item> ARDANIUM_PICKAXE = REGISTRY.register("ardanium_pickaxe", () -> new ArdaniumPickaxeItem());
	public static final RegistryObject<Item> ARDANIUM_SWORD = REGISTRY.register("ardanium_sword", () -> new ArdaniumSwordItem());
	public static final RegistryObject<Item> ARDANIUM_AXE = REGISTRY.register("ardanium_axe", () -> new ArdaniumAxeItem());
	public static final RegistryObject<Item> ARDANIUM_HOE = REGISTRY.register("ardanium_hoe", () -> new ArdaniumHoeItem());
	public static final RegistryObject<Item> ARDANIUM_SHOVEL = REGISTRY.register("ardanium_shovel", () -> new ArdaniumShovelItem());
	public static final RegistryObject<Item> ARDANIUM_ARMOR_HELMET = REGISTRY.register("ardanium_armor_helmet", () -> new ArdaniumArmorItem.Helmet());
	public static final RegistryObject<Item> ARDANIUM_ARMOR_CHESTPLATE = REGISTRY.register("ardanium_armor_chestplate", () -> new ArdaniumArmorItem.Chestplate());
	public static final RegistryObject<Item> ARDANIUM_ARMOR_LEGGINGS = REGISTRY.register("ardanium_armor_leggings", () -> new ArdaniumArmorItem.Leggings());
	public static final RegistryObject<Item> ARDANIUM_ARMOR_BOOTS = REGISTRY.register("ardanium_armor_boots", () -> new ArdaniumArmorItem.Boots());
	public static final RegistryObject<Item> ARDANIUM_GRASS = block(MinecraftmodModBlocks.ARDANIUM_GRASS);
	public static final RegistryObject<Item> ARDANIUM_WATER_BUCKET = REGISTRY.register("ardanium_water_bucket", () -> new ArdaniumWaterItem());
	public static final RegistryObject<Item> ARDANIUM_DIMENSION = REGISTRY.register("ardanium_dimension", () -> new ArdaniumDimensionItem());
	public static final RegistryObject<Item> ARDANIUM_LOG = block(MinecraftmodModBlocks.ARDANIUM_LOG);
	public static final RegistryObject<Item> ARDANIUM_LEAVE = block(MinecraftmodModBlocks.ARDANIUM_LEAVE);
	public static final RegistryObject<Item> ARDANIUM_ANIMAL_SPAWN_EGG = REGISTRY.register("ardanium_animal_spawn_egg", () -> new ForgeSpawnEggItem(MinecraftmodModEntities.ARDANIUM_ANIMAL, -6750055, -16724788, new Item.Properties()));
	public static final RegistryObject<Item> ARDANIUM_ANIMAL_2_SPAWN_EGG = REGISTRY.register("ardanium_animal_2_spawn_egg", () -> new ForgeSpawnEggItem(MinecraftmodModEntities.ARDANIUM_ANIMAL_2, -10092442, -10079488, new Item.Properties()));
	public static final RegistryObject<Item> DEEVE_FRAGMENT_ONE = REGISTRY.register("deeve_fragment_one", () -> new DeeveFragmentOneItem());
	public static final RegistryObject<Item> DEEVE_FRAGMENT_TWO = REGISTRY.register("deeve_fragment_two", () -> new DeeveFragmentTwoItem());
	public static final RegistryObject<Item> DEEVE_FRAGMENT_THREE = REGISTRY.register("deeve_fragment_three", () -> new DeeveFragmentThreeItem());
	public static final RegistryObject<Item> ARDANIUM_ANIMAL_3_SPAWN_EGG = REGISTRY.register("ardanium_animal_3_spawn_egg", () -> new ForgeSpawnEggItem(MinecraftmodModEntities.ARDANIUM_ANIMAL_3, -10066177, -65332, new Item.Properties()));
	public static final RegistryObject<Item> ARDANIUM_STONE = block(MinecraftmodModBlocks.ARDANIUM_STONE);

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
