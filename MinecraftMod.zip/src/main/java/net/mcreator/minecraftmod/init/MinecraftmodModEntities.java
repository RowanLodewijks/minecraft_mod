
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minecraftmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.minecraftmod.entity.DeeveEntity;
import net.mcreator.minecraftmod.entity.ArdaniumAnimalEntity;
import net.mcreator.minecraftmod.entity.ArdaniumAnimal3Entity;
import net.mcreator.minecraftmod.entity.ArdaniumAnimal2Entity;
import net.mcreator.minecraftmod.MinecraftmodMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MinecraftmodModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MinecraftmodMod.MODID);
	public static final RegistryObject<EntityType<DeeveEntity>> DEEVE = register("deeve",
			EntityType.Builder.<DeeveEntity>of(DeeveEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(100).setUpdateInterval(3).setCustomClientFactory(DeeveEntity::new)

					.sized(0.6f, 1.7f));
	public static final RegistryObject<EntityType<ArdaniumAnimalEntity>> ARDANIUM_ANIMAL = register("ardanium_animal",
			EntityType.Builder.<ArdaniumAnimalEntity>of(ArdaniumAnimalEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ArdaniumAnimalEntity::new)

					.sized(1f, 1f));
	public static final RegistryObject<EntityType<ArdaniumAnimal2Entity>> ARDANIUM_ANIMAL_2 = register("ardanium_animal_2",
			EntityType.Builder.<ArdaniumAnimal2Entity>of(ArdaniumAnimal2Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ArdaniumAnimal2Entity::new)

					.sized(1f, 10f));
	public static final RegistryObject<EntityType<ArdaniumAnimal3Entity>> ARDANIUM_ANIMAL_3 = register("ardanium_animal_3",
			EntityType.Builder.<ArdaniumAnimal3Entity>of(ArdaniumAnimal3Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ArdaniumAnimal3Entity::new)

					.sized(0.9f, 1.4f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			DeeveEntity.init();
			ArdaniumAnimalEntity.init();
			ArdaniumAnimal2Entity.init();
			ArdaniumAnimal3Entity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(DEEVE.get(), DeeveEntity.createAttributes().build());
		event.put(ARDANIUM_ANIMAL.get(), ArdaniumAnimalEntity.createAttributes().build());
		event.put(ARDANIUM_ANIMAL_2.get(), ArdaniumAnimal2Entity.createAttributes().build());
		event.put(ARDANIUM_ANIMAL_3.get(), ArdaniumAnimal3Entity.createAttributes().build());
	}
}
