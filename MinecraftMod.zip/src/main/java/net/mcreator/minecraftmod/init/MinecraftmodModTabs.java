
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minecraftmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.CreativeModeTabEvent;

import net.minecraft.world.item.CreativeModeTabs;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MinecraftmodModTabs {
	@SubscribeEvent
	public static void buildTabContentsVanilla(CreativeModeTabEvent.BuildContents tabData) {

		if (tabData.getTab() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(MinecraftmodModBlocks.ARDANIUM_BLOCK.get().asItem());
			tabData.accept(MinecraftmodModBlocks.ARDANIUM_ORE.get().asItem());
		}

		if (tabData.getTab() == CreativeModeTabs.COMBAT) {
			tabData.accept(MinecraftmodModItems.ARDANIUM_SWORD.get());
			tabData.accept(MinecraftmodModItems.ARDANIUM_ARMOR_HELMET.get());
			tabData.accept(MinecraftmodModItems.ARDANIUM_ARMOR_CHESTPLATE.get());
			tabData.accept(MinecraftmodModItems.ARDANIUM_ARMOR_LEGGINGS.get());
			tabData.accept(MinecraftmodModItems.ARDANIUM_ARMOR_BOOTS.get());
		}

		if (tabData.getTab() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(MinecraftmodModItems.DEEVE_SPAWN_EGG.get());
			tabData.accept(MinecraftmodModItems.ARDANIUM_ANIMAL_SPAWN_EGG.get());
			tabData.accept(MinecraftmodModItems.ARDANIUM_ANIMAL_2_SPAWN_EGG.get());
			tabData.accept(MinecraftmodModItems.ARDANIUM_ANIMAL_3_SPAWN_EGG.get());
		}

		if (tabData.getTab() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(MinecraftmodModItems.ARDANIUM_INGOT.get());
		}

		if (tabData.getTab() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(MinecraftmodModItems.ARDANIUM_PICKAXE.get());
			tabData.accept(MinecraftmodModItems.ARDANIUM_AXE.get());
			tabData.accept(MinecraftmodModItems.ARDANIUM_HOE.get());
			tabData.accept(MinecraftmodModItems.ARDANIUM_SHOVEL.get());
			tabData.accept(MinecraftmodModItems.ARDANIUM_DIMENSION.get());
		}

		if (tabData.getTab() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(MinecraftmodModBlocks.ARDANIUM_GRASS.get().asItem());
			tabData.accept(MinecraftmodModBlocks.ARDANIUM_LOG.get().asItem());
			tabData.accept(MinecraftmodModBlocks.ARDANIUM_LEAVE.get().asItem());
			tabData.accept(MinecraftmodModBlocks.ARDANIUM_STONE.get().asItem());
		}
	}
}
