
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minecraftmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.minecraftmod.block.ArdaniumWaterBlock;
import net.mcreator.minecraftmod.block.ArdaniumStoneBlock;
import net.mcreator.minecraftmod.block.ArdaniumOreBlock;
import net.mcreator.minecraftmod.block.ArdaniumLogBlock;
import net.mcreator.minecraftmod.block.ArdaniumLeaveBlock;
import net.mcreator.minecraftmod.block.ArdaniumGrassBlock;
import net.mcreator.minecraftmod.block.ArdaniumDimensionPortalBlock;
import net.mcreator.minecraftmod.block.ArdaniumBlockBlock;
import net.mcreator.minecraftmod.MinecraftmodMod;

public class MinecraftmodModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MinecraftmodMod.MODID);
	public static final RegistryObject<Block> ARDANIUM_BLOCK = REGISTRY.register("ardanium_block", () -> new ArdaniumBlockBlock());
	public static final RegistryObject<Block> ARDANIUM_ORE = REGISTRY.register("ardanium_ore", () -> new ArdaniumOreBlock());
	public static final RegistryObject<Block> ARDANIUM_GRASS = REGISTRY.register("ardanium_grass", () -> new ArdaniumGrassBlock());
	public static final RegistryObject<Block> ARDANIUM_WATER = REGISTRY.register("ardanium_water", () -> new ArdaniumWaterBlock());
	public static final RegistryObject<Block> ARDANIUM_DIMENSION_PORTAL = REGISTRY.register("ardanium_dimension_portal", () -> new ArdaniumDimensionPortalBlock());
	public static final RegistryObject<Block> ARDANIUM_LOG = REGISTRY.register("ardanium_log", () -> new ArdaniumLogBlock());
	public static final RegistryObject<Block> ARDANIUM_LEAVE = REGISTRY.register("ardanium_leave", () -> new ArdaniumLeaveBlock());
	public static final RegistryObject<Block> ARDANIUM_STONE = REGISTRY.register("ardanium_stone", () -> new ArdaniumStoneBlock());
}
